//
//  ViewController.swift
//  Contest
//
//  Created by Quinn Wienke on 4/14/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var emailTextField: UITextField!
    
   override func viewDidLoad() {
        
    }
    
    
    @IBAction func buttonPressd(_ sender: Any) {
        if emailTextField.text?.isEmpty == true {
            animation()
        
        } else {
            performSegue(withIdentifier: "toEnteredView", sender: nil)
        }
    }
    
    private func animation() {
        UIView.animate(withDuration: 0.2, animations: {
            let rightTransform  = CGAffineTransform(translationX: 20, y: 0)
            self.emailTextField.transform = rightTransform
        }) { (_) in
            UIView.animate(withDuration: 0.2, animations: {
                self.emailTextField.transform = CGAffineTransform.identity
            })
        }
    }
        }

   

    
        
    
    

